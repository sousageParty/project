window.onload = function () {
    var socket = io('http://localhost:3000');

    var EVENTS = {
        USER_LOGIN: 'user login',
        USER_LOGOUT: 'user logout',
        USER_START_GAME: 'user start game'
    };

    $("#button").click(function () {
        socket.emit(EVENTS.USER_LOGIN, { name: $("#name")[0].value, login: $("#login")[0].value });
    });
    socket.on(EVENTS.USER_LOGIN, function (data) {
        console.log(data);
        if (data == null) {
            $("#hint_2").show();
            if ($("#name")[0].value == ""){
                $("#hint_1").show();
                $("#hint_2").hide();
                $("#div_name").attr("class", "form-group has-error");
                $("#hint_1")[0].innerHTML = "Введите имя";
            } else {
                $("#hint_1").hide();
                $("#div_name").attr("class", "form-group has-success");
            }
            if ($("#login")[0].value != ""){
                $("#div_login").attr("class", "form-group has-error");
                $("#hint_2")[0].innerHTML = "Такой логин уже существует";
            }else{
                $("#div_login").attr("class", "form-group has-error");
                $("#hint_2")[0].innerHTML = "Введите логин";
            }
        } else {
            $("#div_login").attr("class", "form-group has-success");
            $("#div_name").attr("class", "form-group has-success");
            $("#hint_1").hide();
            $("#hint_2").hide();
        }
    });
};	