var SETTINGS = {};

SETTINGS.func = function() {
	return 'Vasya';
};

SETTINGS.func2 = function() {
	return 'Petya';
};

module.exports = SETTINGS;
