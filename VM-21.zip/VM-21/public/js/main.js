window.onload = function () {

    var socket = io('http://localhost:3000');

    var EVENTS = {
        USER_LOGIN: 'user login',
        USER_LOGOUT: 'user logout',
        USER_AUTHORIZED: 'user authorized',
        USER_REGISTERED: 'user registered',
        USER_START_GAME: 'user start game'
    };

    var SignIn = $('#Sign_in');
    var SignUp = $("#Sign_up");

    SignIn.on('click', function () {
        socket.emit(EVENTS.USER_AUTHORIZED, {
            login: $("#inputLoginAuth").val(),
            password: $("#inputPasswordAuth").val()
        });
    });

    SignUp.on('click', function () {
        socket.emit(EVENTS.USER_REGISTERED, {
            name: $("#inputNameRegis").val(),
            login: $("#inputLoginRegis").val(),
            password: $("#inputPasswordRegis").val()
        });
    });
    
    socket.on(EVENTS.USER_AUTHORIZED, function (data) {
        console.log(data);
        if (data == null) {
            $('#hintAuth').html("Неверный Логин и(или) Пароль");
        }else{
            $('#hintAuth').html("");
        }
    });

    socket.on(EVENTS.USER_REGISTERED, function (data) {
        console.log(data);
        if (data){
            $('#hintRegis').html("Вы зарегистрировали нового пользователя");
        }else{
            $('#hintRegis').html("Такой логин занят попробуйте снова");
        }
    });
};	
